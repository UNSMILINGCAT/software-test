<?php
$lang->resource->admin->xuanxuan = 'xuanxuan';
$lang->admin->methodOrder[26] = 'xuanxuan';

if(!isset($lang->resource->setting)) $lang->resource->setting = new stdclass();
$lang->resource->setting->xuanxuan    = 'xuanxuan';
$lang->resource->setting->downloadxxd = 'downloadXXD';

$lang->setting->methodOrder[26] = 'xuanxuan';
$lang->setting->methodOrder[31] = 'downloadxxd';

$lang->resource->chat = new stdclass();
$lang->resource->chat->getChatUsers  = 'getChatUsers';
$lang->resource->chat->getChatGroups = 'getChatGroups';
$lang->resource->chat->notifyMSG     = 'notifyMSG';

$lang->resource->client = new stdclass();
$lang->resource->client->browse       = 'browse';
$lang->resource->client->create       = 'create';
$lang->resource->client->edit         = 'edit';
$lang->resource->client->delete       = 'delete';
$lang->resource->client->checkUpgrade = 'checkUpgrade';
