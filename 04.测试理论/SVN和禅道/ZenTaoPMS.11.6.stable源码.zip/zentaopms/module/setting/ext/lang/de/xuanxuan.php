<?php 
$lang->setting->common      = 'Settings';
$lang->setting->xuanxuan    = 'Client';
$lang->setting->downloadXXD = 'Download XXD';
