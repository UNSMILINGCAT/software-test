<?php
$lang->setting->common      = '設置';
$lang->setting->xuanxuan    = '客戶端整合';
$lang->setting->downloadXXD = '下載喧喧服務端';
