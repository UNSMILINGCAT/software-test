<?php
$lang->setting->common      = '设置';
$lang->setting->xuanxuan    = '客户端集成';
$lang->setting->downloadXXD = '下载喧喧服务端';
