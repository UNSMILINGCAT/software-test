$(function()
{
    $('.table-grouped .c-side').removeAttr('title');
});
