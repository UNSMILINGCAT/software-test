$(function()
{
    $('#' + browseType + 'Tab').addClass('active');
});
