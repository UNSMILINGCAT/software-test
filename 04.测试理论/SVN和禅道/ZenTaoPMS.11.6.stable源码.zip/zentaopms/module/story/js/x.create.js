$(function()
{
    $('#sourceNote').prev('span').remove();
    $('#sourceNote').remove();
    $('table tbody tr th').addClass('w-70px');
});
