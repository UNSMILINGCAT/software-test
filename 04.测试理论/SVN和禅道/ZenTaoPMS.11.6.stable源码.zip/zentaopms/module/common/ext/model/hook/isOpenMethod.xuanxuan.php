<?php
if($module == 'entry'  and $method == 'visit') return true;
