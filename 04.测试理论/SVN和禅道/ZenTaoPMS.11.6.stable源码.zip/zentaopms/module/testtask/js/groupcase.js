$(document).ready(function()
{
    $('#' + browseType + 'Tab').addClass('active');
    $('.c-side.has-btn').removeAttr('title');
});
