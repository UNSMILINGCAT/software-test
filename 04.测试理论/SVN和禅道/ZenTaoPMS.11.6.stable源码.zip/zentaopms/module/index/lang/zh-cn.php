<?php
$lang->index->common = '首页';
$lang->index->index  = '首页';
