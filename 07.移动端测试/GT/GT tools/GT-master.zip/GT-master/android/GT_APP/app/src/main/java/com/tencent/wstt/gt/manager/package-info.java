/**
 * <b>本包的职责：</b><br>
 * 1、在下个版本，本包将拆分成拆分出engine和manager两个控制模块
 */
package com.tencent.wstt.gt.manager;