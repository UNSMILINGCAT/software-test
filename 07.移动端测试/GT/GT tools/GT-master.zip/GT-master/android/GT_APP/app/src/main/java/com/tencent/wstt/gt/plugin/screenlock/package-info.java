/**
 * <b>本包的职责：</b><br>
 * 1、锁定手机不休眠的插件
 */
package com.tencent.wstt.gt.plugin.screenlock;