/**
 * <b>本包的职责：</b><br>
 * 1、处理与GT SDK连接交互
 */
package com.tencent.wstt.gt.communicate;