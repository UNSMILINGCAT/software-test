package com.tencent.wstt.gt.proInfo.floatView;

/**
 * Created by p_gumingcai on 2017/7/26.
 */

public interface OnDataChangedListener {

    void onDataChanged();
}
