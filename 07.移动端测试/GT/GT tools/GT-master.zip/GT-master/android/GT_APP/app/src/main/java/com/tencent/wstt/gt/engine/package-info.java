
/**
 <b>本包的职责：</b><br>
 * 1、获取基本性能指标数据的引擎
 * 2、获取指定被测APP性能指标数据的引擎
 */
package com.tencent.wstt.gt.engine;