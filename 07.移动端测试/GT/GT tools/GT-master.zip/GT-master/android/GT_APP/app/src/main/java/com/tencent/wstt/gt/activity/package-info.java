/**
 * <b>本包的职责：</b><br>
 * 1、GT Console的大部分UI类在此定义，除了插件模块的UI类在各插件模块中
 */
package com.tencent.wstt.gt.activity;