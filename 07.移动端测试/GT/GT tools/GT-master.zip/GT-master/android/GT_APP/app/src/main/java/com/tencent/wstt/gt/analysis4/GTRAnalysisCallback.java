package com.tencent.wstt.gt.analysis4;

/**
 * Created by p_hongjcong on 2017/8/14.
 */

public class GTRAnalysisCallback {
    public void refreshPid(GTRAnalysisResult gtrAnalysisResult) {

    }

    public void refreshAppInfo(GTRAnalysisResult gtrAnalysisResult) {

    }

    public void refreshDeviceInfo(GTRAnalysisResult gtrAnalysisResult) {

    }

    public void refreshNormalInfo(GTRAnalysisResult gtrAnalysisResult) {

    }

    public void refreshFragmentInfo(GTRAnalysisResult gtrAnalysisResult) {

    }

    public void refreshPageLoadInfo(GTRAnalysisResult gtrAnalysisResult) {

    }

    public void refreshViewDrawInfo(GTRAnalysisResult gtrAnalysisResult) {

    }

    public void refreshViewBuildInfo(GTRAnalysisResult gtrAnalysisResult) {

    }

    public void refreshSMInfo(GTRAnalysisResult gtrAnalysisResult) {

    }

    public void refreshBlockInfo(GTRAnalysisResult gtrAnalysisResult) {

    }

    public void refreshIOInfo(GTRAnalysisResult gtrAnalysisResult) {

    }

    public void refreshGCInfo(GTRAnalysisResult gtrAnalysisResult) {

    }

    public void refreshLogInfo(GTRAnalysisResult gtrAnalysisResult) {

    }
}
