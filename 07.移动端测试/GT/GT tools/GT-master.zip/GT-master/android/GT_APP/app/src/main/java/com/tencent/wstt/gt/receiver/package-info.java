/**
 * <b>本包的职责：</b><br>
 * 1、抓包插件
 */
package com.tencent.wstt.gt.receiver;