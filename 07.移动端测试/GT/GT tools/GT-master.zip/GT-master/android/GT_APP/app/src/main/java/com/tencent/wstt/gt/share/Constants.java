package com.tencent.wstt.gt.share;

public class Constants {
	// APP_ID 替换为你的应用从官方网站申请到的合法appId
    public static final String APP_ID = "wx660c221a8f440d81";

}
