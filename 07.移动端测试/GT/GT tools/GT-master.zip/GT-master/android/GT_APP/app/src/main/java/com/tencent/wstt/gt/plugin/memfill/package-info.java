
/**
 * 内存填充的插件
 */
package com.tencent.wstt.gt.plugin.memfill;