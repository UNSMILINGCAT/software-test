/**
 * <b>本包的职责：</b><br>
 * 1、插件们共享一个Andorid服务，不需要单独在manifest文件中定义
 */
package com.tencent.wstt.gt.plugin.internal;