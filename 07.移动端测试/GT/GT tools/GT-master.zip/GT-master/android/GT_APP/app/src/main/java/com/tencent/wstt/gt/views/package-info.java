/**
 * <b>本包的职责：</b><br>
 * 1、GT的自定义视图
 */
package com.tencent.wstt.gt.views;