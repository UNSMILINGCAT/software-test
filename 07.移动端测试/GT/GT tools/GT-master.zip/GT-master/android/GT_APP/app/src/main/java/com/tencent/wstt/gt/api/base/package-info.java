/**
 * <b>本包的职责：</b><br>
 * 1、GT Console的核心功能的内部接口api，主要提供给各插件使用
 */
package com.tencent.wstt.gt.api.base;