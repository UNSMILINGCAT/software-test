/**
 * <b>本包的职责：</b><br>
 * 1、GT Console定义的所有Service类
 */
package com.tencent.wstt.gt.service;