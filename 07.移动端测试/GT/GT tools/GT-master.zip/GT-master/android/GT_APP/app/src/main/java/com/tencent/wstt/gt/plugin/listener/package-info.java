/**
 * <b>本包的职责：</b><br>
 * 1、无使用，预计下个版本废弃
 */
package com.tencent.wstt.gt.plugin.listener;