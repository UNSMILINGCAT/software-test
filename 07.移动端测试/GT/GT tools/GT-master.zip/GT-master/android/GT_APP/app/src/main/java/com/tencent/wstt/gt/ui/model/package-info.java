/**
 * <b>本包的职责：</b><br>
 * 1、UI模块所使用的数据源定义
 */
package com.tencent.wstt.gt.ui.model;