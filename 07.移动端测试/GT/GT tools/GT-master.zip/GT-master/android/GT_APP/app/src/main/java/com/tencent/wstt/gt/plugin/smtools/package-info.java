/**
 * 基于Logcat卡帧日志的流畅度实现
 */
package com.tencent.wstt.gt.plugin.smtools;