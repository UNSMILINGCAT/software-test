/**
 * <b>本包的职责：</b><br>
 * 1、负责默认设置与数据的持久化
 */
package com.tencent.wstt.gt.dao;