
/**
 <b>本包的职责：</b><br>
 * 1、LogCat日志模块，从CatLog精简而来
 */
package com.tencent.wstt.gt.log.logcat;