/**
 * <b>本包的职责：</b><br>
 * 1、插件模块
 */
package com.tencent.wstt.gt.plugin;