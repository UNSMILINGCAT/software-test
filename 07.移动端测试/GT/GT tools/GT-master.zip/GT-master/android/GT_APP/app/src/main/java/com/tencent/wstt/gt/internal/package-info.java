
/**
 *内部包，目前主要内容包括：GT的自定义守护线程
 */
package com.tencent.wstt.gt.internal;