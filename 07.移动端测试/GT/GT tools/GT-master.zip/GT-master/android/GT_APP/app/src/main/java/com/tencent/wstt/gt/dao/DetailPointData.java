package com.tencent.wstt.gt.dao;

/**
 * Created by p_hongjcong on 2017/8/28.
 */

public class DetailPointData {

    public DetailPointData(double x, double y){
        this.x = x;
        this.y = y;
    }

    public double x;
    public double y;
}
