/**
 * <b>本包的职责：</b><br>
 * 1、日志模块，包括耗时统计的模型与逻辑
 */
package com.tencent.wstt.gt.log;