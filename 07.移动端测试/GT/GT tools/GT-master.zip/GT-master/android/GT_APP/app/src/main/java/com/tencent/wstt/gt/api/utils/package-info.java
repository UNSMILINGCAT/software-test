/**
 * <b>本包的职责：</b><br>
 * 1、GT Console核心模块可提供给外围模块使用的工具类，主要提供给各插件使用
 */
package com.tencent.wstt.gt.api.utils;