package com.gtr.test;

/**
 * Created by p_guilfu on 2018/1/15.
 */

public interface UserStrings {
	// 出入参
	public static final String 并发线程数 = "并发线程数";
	public static final String KeepAlive = "KeepAlive";
	public static final String 连接超时 = "连接超时";
	public static final String 读超时 = "读超时";
	public static final String 下载耗时 = "下载耗时";
	public static final String NumberOfDownloadedPics = "NumberOfDownloadedPics";
	public static final String 实际带宽 = "实际带宽";
	public static final String singlePicSpeed = "singlePicSpeed";
	
	// 日志、性能的tag
	public static final String 下载完成后到UI展示 = "下载完成后到UI展示";
	public static final String 速度统计 = "速度统计";

	public static final String UI处理图片 = "UI处理图片";
	public static final String 线程内统计 = "线程内统计";
	public static final String Http响应耗时 = "Http响应耗时";
	public static final String 图片下载 = "图片下载";
}
