package com.gtr.test;

import android.util.Log;


/**
 * Created by p_hongjcong on 2017/7/12.
 */

public class TestJNI {

    public void test(){
        //Log.e("dsdsdasd",""+ InlineHook.test());
    }
}
